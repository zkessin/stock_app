release-remote-ctl info @args
